export default {
	namespaced: true,
	state: {
		address: JSON.parse(uni.getStorageSync('address') || '{}'),
		token: '',
		userinfo: JSON.parse(uni.getStorageSync('userinfo') || '{}'),
	},
	mutations: {
		updateAddress(state, address) {
			state.address = address;
			this.commit("storeUser/saveAddressToStorage");
		},
		saveAddressToStorage(state) {
			// 把数据存储到本地 chrome引擎
			uni.setStorageSync('address', JSON.stringify(state.address || {}));
		},
		updateUserInfo(state, userinfo){
			state.userinfo = userinfo;
				this.commit("storeUser/saveUserInfoToStorage");
		},
		saveUserInfoToStorage(state) {
			// 把数据存储到本地 chrome引擎
			uni.setStorageSync('userinfo', JSON.stringify(state.userinfo || {}));
		},
		
	},
	actions: {},
	getters: {
		addstr(state) {
			// 判断
			if (state.address.provinceName === '') return '';
			// 拼接字符串 广东省
			return `${state.address.provinceName} ${state.address.cityName} ${state.address.countyName} ${state.address.detailInfo}`
		}
	}
}
